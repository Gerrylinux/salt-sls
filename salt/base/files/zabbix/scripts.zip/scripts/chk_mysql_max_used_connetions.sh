#!/bin/bash

#mysql当前连接数
mysql -uroot -pwww.qaz  -e "show status like 'Max_used_connections';"| grep -v Value |awk '{print $2}'

