#!/bin/bash

#获取mysql最大连接数
mysql -uroot -pwww.qaz  -e "show variables like 'max_connections';"| grep -v Value |awk '{print $2}'

